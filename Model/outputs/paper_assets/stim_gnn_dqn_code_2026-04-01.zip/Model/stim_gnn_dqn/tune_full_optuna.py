from __future__ import annotations

import json
import random
from dataclasses import replace
from pathlib import Path

import numpy as np
import optuna
import torch

from stim_gnn_dqn.config import Config
from stim_gnn_dqn.environment import CapacityConstrainedEnv
from stim_gnn_dqn.evaluate import run_episode
from stim_gnn_dqn.data_loader import build_dataset
from stim_gnn_dqn.preprocess import build_static_parameters
from stim_gnn_dqn.train import train_rl


def _make_env(cfg: Config, dataset, static, device: str) -> CapacityConstrainedEnv:
    return CapacityConstrainedEnv(
        dataset=dataset,
        static=static,
        horizon=cfg.horizon,
        max_budget=cfg.max_budget,
        history_len=cfg.history_len,
        reward_alpha=cfg.reward_alpha,
        reward_beta=cfg.reward_beta,
        reward_kappa=cfg.reward_kappa,
        reward_eta=cfg.reward_eta,
        reward_deactivation_lambda=cfg.reward_deactivation_lambda,
        reward_saturation_threshold=cfg.reward_saturation_threshold,
        reward_saturation_weight=cfg.reward_saturation_weight,
        reward_zeta=cfg.reward_zeta,
        incident_prob=cfg.incident_prob_eval,
        incident_factor_low=cfg.incident_factor_low,
        incident_factor_high=cfg.incident_factor_high,
        incident_duration_min=cfg.incident_duration_min,
        incident_duration_max=cfg.incident_duration_max,
        incident_edge_fraction=cfg.incident_edge_fraction,
        device=device,
    )


def objective(trial: optuna.trial.Trial) -> float:
    cfg = replace(
        Config(),
        reward_alpha=0.01,
        reward_kappa=trial.suggest_float("reward_kappa", 0.5, 5.0),
        reward_beta=trial.suggest_float("reward_beta", 2.0, 15.0),
        reward_eta=trial.suggest_float("reward_eta", 5.0, 30.0),
        reward_deactivation_lambda=trial.suggest_float("reward_deactivation_lambda", 0.05, 0.5),
        gconv_hops_k=trial.suggest_int("gconv_hops_k", 2, 4),
        dqn_lookahead_h=trial.suggest_int("dqn_lookahead_h", 2, 8),
        max_budget=10,
        reward_saturation_threshold=0.72,
        episodes=40,
        workdir=str(Path("Model/outputs/optuna_trials") / f"trial_{trial.number:03d}"),
    )

    random.seed(cfg.seed)
    np.random.seed(cfg.seed)
    torch.manual_seed(cfg.seed)

    try:
        model, _history = train_rl(cfg, save_artifacts=False)
    except Exception as exc:
        print(f"Trial {trial.number} failed due to: {exc}")
        return -1e9

    device = "cuda" if torch.cuda.is_available() else "cpu"
    dataset = build_dataset(**cfg.dataset_kwargs)
    static = build_static_parameters(
        dataset=dataset,
        horizon=cfg.horizon,
        train_ratio=cfg.train_ratio,
        val_ratio=cfg.val_ratio,
        q=cfg.capacity_quantile,
        threshold_alpha=cfg.threshold_alpha,
        validation_start=cfg.validation_start,
        validation_end=cfg.validation_end,
    )

    starts = static.val_starts[:3]
    if not starts:
        return -1e9

    env = _make_env(cfg, dataset, static, device)
    model.eval()

    scores = []
    for s in starts:
        m = run_episode(env, "rl", model, s)
        score = m.j_int + 25.0 * m.stability_score - 10.0 * m.flicker_rate
        scores.append(float(score))

    return float(np.mean(scores)) if scores else -1e9


if __name__ == "__main__":
    study = optuna.create_study(direction="maximize")
    study.optimize(objective, n_trials=50)

    out = Path("Model/outputs/optuna_best_params_full.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        json.dumps(
            {
                "best_params": study.best_params,
                "best_value": study.best_value,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print("BEST:", study.best_params)
    print("SAVED:", out)
